<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tamales extends Model
{
    public $timestamps = false;
    protected $table = 'tamales';
}
