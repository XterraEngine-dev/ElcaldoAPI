<?php

namespace App;
use Illuminate\Database\Seeder;

use Illuminate\Database\Eloquent\Model;

class Caldos extends Model
{
    public $timestamps = false;
    protected $table= 'caldos';

}
