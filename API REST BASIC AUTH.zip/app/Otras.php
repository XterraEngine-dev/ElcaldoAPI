<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Otras extends Model
{
    public $timestamps = false;
    protected $table = 'otras';
}
