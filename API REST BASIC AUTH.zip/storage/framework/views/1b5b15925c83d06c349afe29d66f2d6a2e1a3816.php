<?php $__env->startSection('content'); ?>
    <a class="btn btn-success pull-right" href="<?php echo e(url('/pasteles/create')); ?>" role="button">Nuevo caldo</a>
    <?php echo $__env->make('pasteles.partials.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<h1 class="text-primary">Control de Pasteles</h1>

<table class="table table-bordered" id="MyTable">
    <thead>
    <tr>
        <th class="text-center">Id</th>
        <th class="text-center">Nombre</th>
        <th class="text-center">Ingrediente</th>
        <th class="text-center">Preparacion</th>
        <th class="text-center">region</th>
        <th class="text-center">imagen</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach($caldos as $caldo): ?>
        <tr>
            <td class="text-center"><?php echo e($caldo->id); ?></td>
            <td class="text-center"><?php echo e($caldo->nombre); ?></td>
            <td class="text-center"><?php echo e($caldo->ingredientes); ?></td>
            <td class="text-center"><?php echo e($caldo->preparacion); ?></td>
            <td class="text-center"><?php echo e($caldo->region); ?></td>
            <td class="text-center"><?php echo e($caldo->imagen); ?></td>
            <td class="text-center"><?php echo e($caldo->created_at); ?></td>

            <?php echo Form::open(['route' => ['caldos.destroy', $caldo->id], 'method' => 'DELETE']); ?>


            <td class="text-center">
                <button type="submit" class="btn btn-danger btn-xs">
                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                </button>
                <a href="<?php echo e(url('/caldos/'.$caldo->id.'/edit')); ?>" class="btn btn-info btn-xs">
                    <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                </a>
            </td>

            <?php echo Form::close(); ?>


        </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
    <tr>
        <th class="text-center">Id</th>
        <th class="text-center">Nombre</th>
        <th class="text-center">Ingrediente</th>
        <th class="text-center">Preparacion</th>
        <th class="text-center">region</th>
        <th class="text-center">imagen</th>
    </tr>
    </tfoot>
</table>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>